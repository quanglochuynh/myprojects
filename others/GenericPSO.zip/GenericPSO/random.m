function res = random(a,b)
    res = a + (b-a) * rand;
end
