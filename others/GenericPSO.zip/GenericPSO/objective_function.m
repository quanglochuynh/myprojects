function result = objective_function( val )
    
end

