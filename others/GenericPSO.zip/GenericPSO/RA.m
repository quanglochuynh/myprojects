function res = RA(a)
    
    res = 0.25 * a^2 - 4*a;
    
     
end

